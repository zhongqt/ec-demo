/**
 * Created with IntelliJ IDEA.
 * User: zhengry
 * Date: 2014/11/6
 * Time: 17:51
 */

// ${appDir}/system/controller/UserController.js
define(['framework/message/GillionMessageModule'], function (GillionMessageModule) {
    return GillionMessageModule.controller('DropdownController', function ($scope) {


    });
});
