define('framework/utilsStringsConstructor', function () {
    return function () {
        return {
            toLowerCase: function () {
                
            }
        }
    };
});