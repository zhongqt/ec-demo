define('framework/utils/ArtTmplUtils', [
    'angular'
], function (angular) {
    return {


    };
});