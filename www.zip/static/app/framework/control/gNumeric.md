数字控件gNumeric
===========
## 使用示例：
    <input g-numeric/>

    <input g-numeric data-allow-negative="false" data-allow-float="true"/>
## 使用说明
*   可应用于 *数字输入框* 和 *文本输入框*,  默认允许输入 **数字** 。
*  `allow-negative="true"`  时, 允许输入 **负号(-)** 。
*  `allow-float="true"` 时, 允许输入 **小数点(.)**。